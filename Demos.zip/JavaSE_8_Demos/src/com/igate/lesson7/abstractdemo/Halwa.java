package com.igate.lesson7.abstractdemo;

public abstract class Halwa extends Sweet{

	public Halwa()
	{
		System.out.println("is a type of Halwa");
	}
	public abstract void makeHalwa();
}
