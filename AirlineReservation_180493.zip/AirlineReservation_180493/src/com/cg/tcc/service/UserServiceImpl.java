package com.cg.tcc.service;

import java.util.ArrayList;









import java.util.regex.Pattern;

import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.dao.IUserDao;
import com.cg.tcc.dao.UserDaoImpl;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;

public class UserServiceImpl implements IUserService{
	
IUserDao dao;
	
	public void setDao(IUserDao dao)
	{
		this.dao = dao;
	}
	
	public UserServiceImpl()
	{
		dao = new UserDaoImpl();
	}

	/*@Override
	public ArrayList<UserBean> getAllUsers() throws UserException {
		// TODO Auto-generated method stub
		return dao.getAllUsers();
	}*/

	@Override
	public ArrayList<FlightInformation> getAllFlights() throws FlightException {
		// TODO Auto-generated method stub
		return dao.getAllFlights();
	}

	@Override
	public int BookFlight(BookingInformation user) throws BookingException {
		// TODO Auto-generated method stub
		return dao.BookFlight(user);
	}

	@Override
	public UserBean getUserByRole(String role) throws UserException {
		// TODO Auto-generated method stub
		return dao.getUserByRole(role);
	}

	@Override
	public FlightInformation getFlightByNo(String flightNo)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.getFlightByNo(flightNo);
	}

	@Override
	public FlightInformation updateFlight(String flightNo, String dep_city)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlight(flightNo, dep_city);
	}

	@Override
	public BookingInformation CancelFlight(int seatno) throws BookingException {
		// TODO Auto-generated method stub
		return dao.CancelFlight(seatno);
	}

	@Override
	public BookingInformation getBookingBySeat(int seatno)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.getBookingBySeat(seatno);
	}

	@Override
	public ArrayList<BookingInformation> getAllBookingDetails()
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.getAllBookingDetails();
	}
	
	public boolean validateEmail(String email)
	{
		String pattern = "^[A-Za-z0-9+_.-]+@(.+)$";
		String eml = ""+email;
		if(Pattern.matches(pattern,eml))
		{
			return true;
		}
		else 
			return false;
	}
	
	

}
