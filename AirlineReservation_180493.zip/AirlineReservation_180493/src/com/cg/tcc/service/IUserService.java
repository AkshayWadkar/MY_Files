package com.cg.tcc.service;

import java.util.ArrayList;

import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;

public interface IUserService {
	
	//ArrayList<UserBean> getAllUsers() throws UserException;
	
	ArrayList<FlightInformation> getAllFlights() throws FlightException;
	
	BookingInformation BookFlight(BookingInformation user) throws BookingException;
	
	UserBean getUserByRole(String role)throws UserException;
	
	FlightInformation getFlightByNo(String flightNo) throws FlightException;
	
	FlightInformation updateFlight(String flightNo,String dep_city)throws FlightException;

}
