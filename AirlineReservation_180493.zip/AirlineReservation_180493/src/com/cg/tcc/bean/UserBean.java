package com.cg.tcc.bean;

public class UserBean {

	private String username, password, role;
	private long mobileno;

	public UserBean(String username, String password, String role, long mobileno) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
		this.mobileno = mobileno;
	}

	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	@Override
	public String toString() {
		return "UserBean [username=" + username + ", password=" + password
				+ ", role=" + role + ", mobileno=" + mobileno + "]";
	}

}
