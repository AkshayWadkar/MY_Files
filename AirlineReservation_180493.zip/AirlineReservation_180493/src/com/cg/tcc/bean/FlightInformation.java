package com.cg.tcc.bean;

import java.sql.Date;


public class FlightInformation {

	private int  firstseats, firstseatfare, bussseats, bussseatsfare;
	private String flightno, airline, dep_city, arr_city;
	private Date dep_date, arr_date;

	public FlightInformation(String flightno, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date, int firstseats,
			int bussseats, int firstseatfare, int bussseatsfare) {
		super();
		this.flightno = flightno;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.firstseats = firstseats;
		this.bussseats = bussseats;
		this.firstseatfare = firstseatfare;
		this.bussseatsfare = bussseatsfare;

	}

	public FlightInformation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFlightno() {
		return flightno;
	}

	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}

	public int getFirstseats() {
		return firstseats;
	}

	public void setFirstseats(int firstseats) {
		this.firstseats = firstseats;
	}

	public int getBussseats() {
		return bussseats;
	}

	public void setBussseats(int bussseats) {
		this.bussseats = bussseats;
	}

	public int getFirstseatfare() {
		return firstseatfare;
	}

	public void setFirstseatfare(int firstseatfare) {
		this.firstseatfare = firstseatfare;
	}

	public int getBussseatsfare() {
		return bussseatsfare;
	}

	public void setBussseatsfare(int bussseatsfare) {
		this.bussseatsfare = bussseatsfare;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDep_city() {
		return dep_city;
	}

	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}

	public String getArr_city() {
		return arr_city;
	}

	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}

	public Date getDep_date() {
		return dep_date;
	}

	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	public Date getArr_date() {
		return arr_date;
	}

	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	@Override
	public String toString() {
		return "FlightInformation [flightno=" + flightno + ", firstseats="
				+ firstseats + ", bussseats=" + bussseats + ", firstseatfare="
				+ firstseatfare + ", bussseatsfare=" + bussseatsfare
				+ ", airline=" + airline + ", dep_city=" + dep_city
				+ ", arr_city=" + arr_city + ", dep_date=" + dep_date
				+ ", arr_date=" + arr_date + "]";
	}

}
