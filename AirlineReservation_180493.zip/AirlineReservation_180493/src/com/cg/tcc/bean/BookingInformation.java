package com.cg.tcc.bean;

public class BookingInformation {

	private int no_of_passengers, total_fare, seat_number;
	private String booking_id, cust_email, class_type, creditcard_info,
			src_city, dest_city;

	public BookingInformation(int no_of_passengers, int total_fare,
			int seat_number, String booking_id, String cust_email,
			String class_type, String creditcard_info, String src_city,
			String dest_city) {
		super();
		this.no_of_passengers = no_of_passengers;
		this.total_fare = total_fare;
		this.seat_number = seat_number;
		this.booking_id = booking_id;
		this.cust_email = cust_email;
		this.class_type = class_type;
		this.creditcard_info = creditcard_info;
		this.src_city = src_city;
		this.dest_city = dest_city;
	}

	public BookingInformation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getNo_of_passengers() {
		return no_of_passengers;
	}

	public void setNo_of_passengers(int no_of_passengers) {
		this.no_of_passengers = no_of_passengers;
	}

	public int getTotal_fare() {
		return total_fare;
	}

	public void setTotal_fare(int total_fare) {
		this.total_fare = total_fare;
	}

	public int getSeat_number() {
		return seat_number;
	}

	public void setSeat_number(int seat_number) {
		this.seat_number = seat_number;
	}

	public String getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(String booking_id) {
		this.booking_id = booking_id;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getClass_type() {
		return class_type;
	}

	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}

	public String getCreditcard_info() {
		return creditcard_info;
	}

	public void setCreditcard_info(String creditcard_info) {
		this.creditcard_info = creditcard_info;
	}

	public String getSrc_city() {
		return src_city;
	}

	public void setSrc_city(String src_city) {
		this.src_city = src_city;
	}

	public String getDest_city() {
		return dest_city;
	}

	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}

	@Override
	public String toString() {
		return "BookingInformation [no_of_passengers=" + no_of_passengers
				+ ", total_fare=" + total_fare + ", seat_number=" + seat_number
				+ ", booking_id=" + booking_id + ", cust_email=" + cust_email
				+ ", class_type=" + class_type + ", creditcard_info="
				+ creditcard_info + ", src_city=" + src_city + ", dest_city="
				+ dest_city + "]";
	}
}
