package com.cg.tcc.bean;

public class BookingInformation {

	 
	private String booking_id, cust_email ;
	private int no_of_passengers;
	private String class_type;
	private float total_fare;
	private int seat_number;
	private String creditcard_info,src_city,dest_city;
	public BookingInformation(String booking_id, String cust_email,
			int no_of_passengers, String class_type, float total_fare,
			int seat_number, String creditcard_info, String src_city,
			String dest_city) {
		super();
		this.booking_id = booking_id;
		this.cust_email = cust_email;
		this.no_of_passengers = no_of_passengers;
		this.class_type = class_type;
		this.total_fare = total_fare;
		this.seat_number = seat_number;
		this.creditcard_info = creditcard_info;
		this.src_city = src_city;
		this.dest_city = dest_city;
	}
	public BookingInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(String booking_id) {
		this.booking_id = booking_id;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	public int getNo_of_passengers() {
		return no_of_passengers;
	}
	public void setNo_of_passengers(int no_of_passengers) {
		this.no_of_passengers = no_of_passengers;
	}
	public String getClass_type() {
		return class_type;
	}
	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}
	public float getTotal_fare() {
		return total_fare;
	}
	public void setTotal_fare(float total_fare) {
		this.total_fare = total_fare;
	}
	public int getSeat_number() {
		return seat_number;
	}
	public void setSeat_number(int seat_number) {
		this.seat_number = seat_number;
	}
	public String getCreditcard_info() {
		return creditcard_info;
	}
	public void setCreditcard_info(String creditcard_info) {
		this.creditcard_info = creditcard_info;
	}
	public String getSrc_city() {
		return src_city;
	}
	public void setSrc_city(String src_city) {
		this.src_city = src_city;
	}
	public String getDest_city() {
		return dest_city;
	}
	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}
	@Override
	public String toString() {
		return "BookingInformation [booking_id=" + booking_id + ", cust_email="
				+ cust_email + ", no_of_passengers=" + no_of_passengers
				+ ", class_type=" + class_type + ", total_fare=" + total_fare
				+ ", seat_number=" + seat_number + ", creditcard_info="
				+ creditcard_info + ", src_city=" + src_city + ", dest_city="
				+ dest_city + "]";
	}

	

	
}
