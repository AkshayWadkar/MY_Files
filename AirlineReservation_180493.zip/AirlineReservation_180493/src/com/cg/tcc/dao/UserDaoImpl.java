package com.cg.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;
import com.cg.tcc.logger.MyLogger;
import com.cg.tcc.util.DBUtil;

public class UserDaoImpl implements IUserDao {
	Connection con;

	Logger logger;

	public UserDaoImpl() {
		con = DBUtil.getConnect();

		logger = MyLogger.getLogger();

	}

	/*
	 * @Override public ArrayList<UserBean> getAllUsers() throws UserException {
	 * // TODO Auto-generated method stub ArrayList<UserBean> list = new
	 * ArrayList<UserBean>(); String qry = "Select * from Users"; try {
	 * Statement stmt = con.createStatement(); ResultSet rs =
	 * stmt.executeQuery(qry); while (rs.next()) {
	 * 
	 * String username = rs.getString(1); String password = rs.getString(2);
	 * String role = rs.getString(3); long mobileno = rs.getLong(4); UserBean
	 * emp = new UserBean(username, password, role, mobileno);
	 * 
	 * Scanner sc = new Scanner(System.in);
	 * 
	 * if ((emp.getRole()).equals("Customer")) {
	 * System.out.println("Enter Username "); String u = sc.next();
	 * System.out.println("Enter Password "); String p = sc.next(); if
	 * ((emp.getUsername()).equals(u)) { if ((emp.getPassword()).equals(p)) {
	 * System.out.println("Welcome customer"); } } else {
	 * System.out.println("incorrect username or password"); } }
	 * 
	 * 
	 * else if ((emp.getRole()).equals("Admin")) {
	 * System.out.println("Enter Username "); String u = sc.next();
	 * System.out.println("Enter Password "); String p = sc.next(); if
	 * ((emp.getUsername()).equals(u)) { if ((emp.getPassword()).equals(p)) {
	 * System.out.println("Welcome Admin"); } } else {
	 * System.out.println("incorrect username or password"); }
	 * System.out.println("Welcome Admin"); } else {
	 * System.out.println("Welcome executive"); } } } catch (SQLException e) {
	 * throw new UserException(e.getMessage()); } return null; }
	 */

	@Override
	public ArrayList<FlightInformation> getAllFlights() throws FlightException {

		ArrayList<FlightInformation> list1 = new ArrayList<FlightInformation>();
		String qry = "select * from flightinformation";

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {
				String flightno = rs.getString(1);
				String airline = rs.getString(2);
				String dep_city = rs.getString(3);
				String arr_city = rs.getString(4);
				Date dep_date = rs.getDate(5);
				Date arr_date = rs.getDate(6);
				int firstseats = rs.getInt(7);
				int firstseatfare = rs.getInt(8);
				int busseats = rs.getInt(9);
				int busseatsfare = rs.getInt(10);

				FlightInformation f = new FlightInformation(flightno, airline,
						dep_city, arr_city, dep_date, arr_date, firstseats,
						firstseatfare, busseats, busseatsfare);

				System.out.println(f);

			}
		} catch (SQLException e) {
			throw new FlightException(e.getMessage());
		}

		return list1;
	}

	@Override
	public int BookFlight(BookingInformation user) throws BookingException {
		// TODO Auto-generated method stub

		String qry = "INSERT INTO BookingInformation VALUES(?,?,?,?,?,?,?,?,?)";
		int no_of_passengers = user.getNo_of_passengers();
		int total_fare = user.getTotal_fare();
		int seat_number = user.getSeat_number();
		String booking_id = user.getBooking_id();
		String cust_email = user.getCust_email();
		String class_type = user.getClass_type();
		String creditcard_info = user.getCreditcard_info();
		String src_city = user.getSrc_city();
		String dest_city = user.getDest_city();
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, no_of_passengers);
			pstmt.setInt(2, total_fare);
			pstmt.setInt(3, seat_number);
			pstmt.setString(4, booking_id);
			pstmt.setString(5, cust_email);
			pstmt.setString(6, class_type);
			pstmt.setString(7, creditcard_info);
			pstmt.setString(8, src_city);
			pstmt.setString(9, dest_city);
		} catch (SQLException e) {
			throw new BookingException(e.getMessage());
		}

		return 0;
	}

	@Override
	public UserBean getUserByRole(String role) throws UserException {
		// TODO Auto-generated method stub
		UserBean emp = null;
		String qry = "Select * from Users where role = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, role);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				String username = rs.getString(1);
				String password = rs.getString(2);
				String role1 = rs.getString(3);
				long mobileno = rs.getLong(4);
				UserBean u = new UserBean(username, password, role, mobileno);
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter Username ");
				String a = sc.next();
				System.out.println("Enter Password ");
				String b = sc.next();
				if ((u.getUsername()).equals(a)) {
					if ((u.getPassword()).equals(b)) {
						System.out.println("Welcome");
					}
				} else {
					System.out.println("incorrect username or password");
				}
			} else
				throw new UserException("User with role " + role + " not found");
		} catch (SQLException e) {
			throw new UserException(e.getMessage());
		}
		return emp;
	}
}
