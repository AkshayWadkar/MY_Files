package com.cg.tcc.dao;

import java.util.ArrayList;


import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;

public interface IUserDao {

	//ArrayList<UserBean> getAllUsers() throws UserException;
	
	ArrayList<FlightInformation> getAllFlights() throws FlightException;
	
	int BookFlight(BookingInformation user) throws BookingException;
	
	UserBean getUserByRole(String role)throws UserException;

}
