package com.cg.tcc.ui;

import java.util.ArrayList;

import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;
import com.cg.tcc.service.IUserService;
import com.cg.tcc.service.UserServiceImpl;

public class MainClass {

	static IUserService service = new UserServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ArrayList<UserBean> no = service.getAllUsers();
			try {
				ArrayList<FlightInformation> a = service.getAllFlights();
			} catch (FlightException e) {
				System.out.println(e.getMessage());
			}
		} catch (UserException e) {
			System.out.println(e.getMessage());
		}

	}
}
