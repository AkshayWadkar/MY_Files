package com.cg.tcc.ui;


import java.util.ArrayList;
import java.util.Scanner;

import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;
import com.cg.tcc.service.IUserService;
import com.cg.tcc.service.UserServiceImpl;

public class MainClass {

	static IUserService service = new UserServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice = 0;
		try (Scanner sc = new Scanner(System.in)) {
			do {
				System.out.println("1-Customer");
				System.out.println("2-Admin");
				System.out.println("3-Executive");
				choice = sc.nextInt();
				switch (choice) {

				case 1:
					String s = "Customer";
					UserBean srchrole = new UserBean();
					try {
						srchrole = service.getUserByRole(s); /*
															 * comparing Role
															 * and verifying
															 * username and
															 * password
															 */
						System.out.println("Customer");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}
					System.out.println("a- Book Flight");
					System.out.println("b- Cancel Flight");
					char value = sc.next().charAt(0);
					switch (value) {
					case 'a':
						BookingInformation emp = acceptBookingDetails();
						if (emp != null) {
							try {
								int id = service.BookFlight(emp);
								System.out.println("inserted and id = " +id);
							} catch (BookingException e) {
								System.out.println(e.getMessage());
							}
						}
						break;

					case 'b':
						System.out.println("Enter your Seat number");
						int a = sc.nextInt();
						BookingInformation deleteId = new BookingInformation();
						try {
							deleteId = service.CancelFlight(a);
							System.out.println("Booking Canceled is: "
									+ deleteId);
						} catch (BookingException e) {
							System.out.println(e.getMessage());
						}

						break;

					}
					break;

				case 2:
					String t = "Admin";
					UserBean srchrol = new UserBean();
					try {
						srchrol = service.getUserByRole(t); /*
															 * comparing Role
															 * and verifying
															 * username and
															 * password
															 */
						System.out.println("Admin");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}
					
					try {
						ArrayList<BookingInformation> a = service
								.getAllBookingDetails();
					} catch (BookingException e) {
						System.out.println(e.getMessage());
					}

					break;

				case 3:
					String u = "Executive";
					UserBean srchrl = new UserBean();
					try {
						srchrl = service.getUserByRole(u); /*
															 * comparing Role
															 * and verifying
															 * username and
															 * password
															 */
						System.out.println("Executive");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}
					System.out.println("\n" + "Please choose below option");
					System.out.println("A- All Flight Details");
					System.out.println("B- Update Flight Details");
					System.out.println("C- Get Flight By Flight No.");
					char l = sc.next().charAt(0);
					switch (l) {
					case 'A':
						try {
							ArrayList<FlightInformation> a = service
									.getAllFlights();
						} catch (FlightException e) {
							System.out.println(e.getMessage());
						}
						break;

					case 'B':
						System.out.println("Enter Departure City");
						String d = sc.next();
						System.out
								.println("Enter Flight No whos updation is needed");
						String z = sc.next();
						FlightInformation upId = new FlightInformation();
						try {
							upId = service.updateFlight(z, d);
							System.out.println("employee serched is: " + upId);
						} catch (FlightException e) {
							System.out.println(e.getMessage());
						}
						break;

					case 'C':
						System.out.println("Enter Flight No");
						String b = sc.next();
						FlightInformation srchNo = new FlightInformation();
						try {
							srchNo = service.getFlightByNo(b);
							System.out.println("Flight serched is: " + srchNo);
						} catch (FlightException e) {
							System.out.println(e.getMessage());
						}
						break;
					}

					/*
					 * case 1:
					 * 
					 * try { ArrayList<UserBean> no = service.getAllUsers(); }
					 * catch (UserException e) {
					 * System.out.println(e.getMessage()); } break;
					 * 
					 * case 2: try { ArrayList<UserBean> no =
					 * service.getAllUsers(); } catch (UserException e) {
					 * System.out.println(e.getMessage()); } break;
					 * 
					 * case 3: try { ArrayList<UserBean> no =
					 * service.getAllUsers(); } catch (UserException e) {
					 * System.out.println(e.getMessage()); } break;
					 */

				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			} while (choice != 0);
		}

	}

	public static BookingInformation acceptBookingDetails() {
		BookingInformation emp = new BookingInformation();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Booking Id");
		String s = sc.next();
		while(true)
		{
			System.out.println("Enter Email");
			String t = sc.next();
			
			if(!service.validateEmail(t))
			{
				continue;
			}
		
		
		System.out.println("Enter no of Passengers");
		int p = sc.nextInt();
		System.out.println("Enter Class type");
		String u = sc.next();
		System.out.println("Enter Fare");
		float q = sc.nextFloat();
		System.out.println("Enter seat No");
		int r = sc.nextInt();
		System.out.println("Enter Credit card details");
		String v = sc.next();
		System.out.println("Enter source city");
		String w = sc.next();
		System.out.println("Enter destination city");
		String x = sc.next();
		

		emp = new BookingInformation();
		emp.setBooking_id(s);
		emp.setCust_email(t);
		emp.setNo_of_passengers(p);
		emp.setClass_type(u);
		emp.setTotal_fare(q);
		emp.setSeat_number(r);
		emp.setCreditcard_info(v);
		emp.setSrc_city(w);
		emp.setDest_city(x);

		return emp;
		}
	}
}
