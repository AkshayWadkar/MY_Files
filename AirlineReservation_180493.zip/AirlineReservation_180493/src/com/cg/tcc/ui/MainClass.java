package com.cg.tcc.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.tcc.bean.BookingInformation;
import com.cg.tcc.bean.FlightInformation;
import com.cg.tcc.bean.UserBean;
import com.cg.tcc.exception.BookingException;
import com.cg.tcc.exception.FlightException;
import com.cg.tcc.exception.UserException;
import com.cg.tcc.service.IUserService;
import com.cg.tcc.service.UserServiceImpl;

public class MainClass {

	static IUserService service = new UserServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice = 0;
		try (Scanner sc = new Scanner(System.in)) {
			do {
				System.out.println("1-Customer");
				System.out.println("2-Admin");
				System.out.println("3-Executive");
				choice = sc.nextInt();
				switch (choice) {

				case 1:
					String s = "Customer";
					UserBean srchrole = new UserBean();
					try {
						srchrole = service.getUserByRole(s);
						System.out.println("Customer");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}
					System.out.println("a-Book Flight");
					System.out.println("b-Cancel Flight");
					char value = sc.next().charAt(0);
					switch (value) {
					case 'a':

					}

					break;
				case 2:
					String t = "Admin";
					UserBean srchrol = new UserBean();
					try {
						srchrol = service.getUserByRole(t);
						System.out.println("Admin");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}

					break;

				case 3:
					String u = "Executive";
					UserBean srchrl = new UserBean();
					try {
						srchrl = service.getUserByRole(u);
						System.out.println("Executive");
					} catch (UserException e) {
						System.out.println(e.getMessage());
					}
					System.out.println("\n" + "Please choose below option");
					System.out.println("A-All Flight Details");
					System.out.println("B-Update Flight Details");
					char l = sc.next().charAt(0);
					switch (l) {
					case 'A':
						try {
							ArrayList<FlightInformation> a = service
									.getAllFlights();
						} catch (FlightException e) {
							System.out.println(e.getMessage());
						}
						break;
					case 'B':

					}

					break;

				/*
				 * case 1:
				 * 
				 * try { ArrayList<UserBean> no = service.getAllUsers(); } catch
				 * (UserException e) { System.out.println(e.getMessage()); }
				 * break;
				 * 
				 * case 2: try { ArrayList<UserBean> no = service.getAllUsers();
				 * } catch (UserException e) {
				 * System.out.println(e.getMessage()); } break;
				 * 
				 * case 3: try { ArrayList<UserBean> no = service.getAllUsers();
				 * } catch (UserException e) {
				 * System.out.println(e.getMessage()); } break;
				 */

				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			} while (choice != 0);
		}

	}
}
